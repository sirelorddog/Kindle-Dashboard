#!/usr/bin/env python3
"""PC-side API for the Kindle dashboard.
Needs: flask requests pillow, and playerctl.  Optional: wpctl / pactl / amixer / xdotool.
"""
import base64, hashlib, io, json, os, random, re, secrets, shlex, shutil, socket, subprocess
import threading, time, urllib.parse
import requests
from flask import Flask, abort, jsonify, redirect, request, send_file
from markupsafe import escape
from PIL import Image, ImageOps

# =============================== SETTINGS ====================================
LAT, LON = 42.3684, -83.3527   # Livonia, MI (approx. city center). Used if AUTO_LOCATION is off or fails
AUTO_LOCATION = True           # find your location from this PC's internet address (city-level, can be off on a VPN)
UNITS = "fahrenheit"           # or "celsius"
WIND_UNIT = "mph"              # or "kmh"
HOST, PORT = "0.0.0.0", 8000   # bind to your LAN IP instead of 0.0.0.0 if you can
SERVER_NAME = ""               # name shown on the Kindle's Devices page (default: this PC's hostname)

# System volume. "auto" picks the first of wpctl (PipeWire), pactl (PulseAudio),
# amixer (ALSA). Or force one of those, or "xdotool" to fake the actual
# XF86Audio* keys (X11 only; triggers whatever your desktop binds to them).
VOLUME_BACKEND = "auto"
VOLUME_STEP = 5                # percent per press

# ------------------------- SPOTIFY (Liked Songs page) -------------------------
# One-time setup:
#  1. developer.spotify.com/dashboard -> Create app (select "Web API").
#     Redirect URI, exactly:  http://127.0.0.1:8000/spotify/callback
#     (if you change PORT above, change it there too; 127.0.0.1, not localhost)
#  2. Paste the app's Client ID below and restart this script.
#  3. On this PC, open  http://127.0.0.1:8000/spotify/login  and approve.
# Needs Spotify Premium on the app owner's account (Spotify's rule since 2026).
# If anything is missing the Kindle just shows the error; there's no fallback.
SPOTIFY_CLIENT_ID = ""
SPOTIFY_DEVICE_NAME = ""        # optional: part of your PC's Spotify device name
LIKED_SORT = "artist"           # "artist" (A-Z, grouped by album) or "added" (newest first)

# ---------------------------- AUDIO OUTPUTS ----------------------------------
# The Kindle's "Controls" page lists your sound outputs and switches between
# them (needs `pactl`, which also works on PipeWire via pipewire-pulse).
# List them with:  pactl list short sinks
AUDIO_COLS = 2
AUDIO_LABELS = {                # exact sink name -> short label for the tile
    # "alsa_output.usb-Some_Headset-00.analog-stereo": "Headphones",
    # "alsa_output.pci-0000_00_1f.3.analog-stereo": "Speakers",
}
AUDIO_HIDE = [                  # hide any sink whose name contains one of these
    # "hdmi",
]

# ----------------------------- STREAM DECK -----------------------------------
# The Kindle reads this layout from /deck. It only ever sends back a button
# position, never a command, so the commands below can't be changed remotely.
# Each button is ONE of:
#   {"label": "...", "action": "<builtin>"}   builtins: play-pause next previous
#                                              vol-up vol-down mute shuffle repeat
#   {"label": "...", "cmd": "some command"}    split safely, no shell
#   {"label": "...", "cmd": ["prog", "arg"]}   explicit argv
#   {"label": "...", "cmd": "a | b", "shell": True}   full shell (use sparingly)
# "\n" in a label makes a line break. Restart this script after editing;
# reopen the Deck page on the Kindle to pick up the change.
DECK_COLS = 3
DECK_PAGES = [
    {"name": "Media", "buttons": [
        {"label": "Prev",          "action": "previous"},
        {"label": "Play /\nPause", "action": "play-pause"},
        {"label": "Next",          "action": "next"},
        {"label": "Vol -",         "action": "vol-down"},
        {"label": "Mute",          "action": "mute"},
        {"label": "Vol +",         "action": "vol-up"},
    ]},
    {"name": "System", "buttons": [
        {"label": "Firefox",     "cmd": "firefox"},
        {"label": "Lock",        "cmd": "loginctl lock-session"},
        {"label": "Notify\ntest", "cmd": ["notify-send", "Hello from the Kindle"]},
        # Playlist preset (untested idea): right-click a playlist in Spotify ->
        # Share -> Copy Spotify URI, then:
        # {"label": "Chill\nmix", "cmd": ["playerctl", "-p", "spotify", "open", "spotify:playlist:PASTE_ID"]},
    ]},
]
# --- Console page (PC status) ---
DISK_PATHS = ["/"]                 # drives to show, e.g. ["/", "/home", "/mnt/games"]
# Things to check are up (green) or down (red). (name, host, port)
SERVICES = [
    # ("Router", "192.168.1.1", 80),
    # ("Plex", "localhost", 32400),
]

# --- Inbox (PC notifications on the Kindle) ---
INBOX_ENABLED = True               # needs `dbus-monitor` (package dbus / dbus-tools)
INBOX_IGNORE_APPS = ["Spotify"]    # apps whose notifications are skipped (song-change spam etc.)
INBOX_MAX = 50                     # how many to keep
# Scripts can also push their own: curl -X POST "http://PC:8000/notify?title=Done&body=Backup finished"
# =============================================================================

app = Flask(__name__)

WMO = {0: "Clear", 1: "Mostly clear", 2: "Partly cloudy", 3: "Overcast",
       45: "Fog", 48: "Rime fog", 51: "Light drizzle", 53: "Drizzle", 55: "Heavy drizzle",
       61: "Light rain", 63: "Rain", 65: "Heavy rain", 66: "Freezing rain", 67: "Freezing rain",
       71: "Light snow", 73: "Snow", 75: "Heavy snow", 77: "Snow grains",
       80: "Showers", 81: "Showers", 82: "Heavy showers", 85: "Snow showers", 86: "Snow showers",
       95: "Thunderstorm", 96: "Thunderstorm, hail", 99: "Thunderstorm, hail"}


# ------------------------------ helpers --------------------------------------
def pctl(*args):
    try:
        r = subprocess.run(["playerctl", *args], capture_output=True, text=True, timeout=3)
        return r.stdout.strip()
    except Exception:
        return ""


def run_detached(argv, shell=False):
    p = subprocess.Popen(argv, shell=shell, stdin=subprocess.DEVNULL,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
    threading.Thread(target=p.wait, daemon=True).start()  # reap, no zombies


def volume_backend():
    if VOLUME_BACKEND != "auto":
        return VOLUME_BACKEND
    for cand in ("wpctl", "pactl", "amixer"):
        if shutil.which(cand):
            return cand
    return None


def vol_cmd(kind):
    b, n = volume_backend(), VOLUME_STEP
    if b == "wpctl":
        return {"up": ["wpctl", "set-volume", "-l", "1.0", "@DEFAULT_AUDIO_SINK@", f"{n}%+"],
                "down": ["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{n}%-"],
                "mute": ["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "toggle"]}[kind]
    if b == "pactl":
        return {"up": ["pactl", "set-sink-volume", "@DEFAULT_SINK@", f"+{n}%"],
                "down": ["pactl", "set-sink-volume", "@DEFAULT_SINK@", f"-{n}%"],
                "mute": ["pactl", "set-sink-mute", "@DEFAULT_SINK@", "toggle"]}[kind]
    if b == "amixer":
        return {"up": ["amixer", "-q", "sset", "Master", f"{n}%+"],
                "down": ["amixer", "-q", "sset", "Master", f"{n}%-"],
                "mute": ["amixer", "-q", "sset", "Master", "toggle"]}[kind]
    if b == "xdotool":
        key = {"up": "XF86AudioRaiseVolume", "down": "XF86AudioLowerVolume",
               "mute": "XF86AudioMute"}[kind]
        return ["xdotool", "key", key]
    raise RuntimeError("no volume tool found (install wpctl/pactl/amixer or set VOLUME_BACKEND)")


def next_loop():
    cur = pctl("loop")
    return {"None": "Playlist", "Playlist": "Track", "Track": "None"}.get(cur, "Playlist")


BUILTIN = {
    "play-pause": lambda: ["playerctl", "play-pause"],
    "next": lambda: ["playerctl", "next"],
    "previous": lambda: ["playerctl", "previous"],
    "vol-up": lambda: vol_cmd("up"),
    "vol-down": lambda: vol_cmd("down"),
    "mute": lambda: vol_cmd("mute"),
    "shuffle": lambda: ["playerctl", "shuffle", "Toggle"],
    "repeat": lambda: ["playerctl", "loop", next_loop()],
}


def resolve(b):
    """Button dict -> (argv_or_string, shell_flag)."""
    if "action" in b:
        return BUILTIN[b["action"]](), False
    cmd = b["cmd"]
    if b.get("shell"):
        return cmd, True
    return (shlex.split(cmd) if isinstance(cmd, str) else list(cmd)), False


# ------------------------------ Spotify API ----------------------------------
SP_API = "https://api.spotify.com/v1"
SP_TOKEN_FILE = os.path.expanduser("~/.config/kindle-dash/spotify.json")
SP_SCOPES = ("user-library-read user-read-playback-state user-modify-playback-state "
             "user-read-currently-playing")
SP_REDIRECT = f"http://127.0.0.1:{PORT}/spotify/callback"
_sp_auth, _sp_tok, _liked_cache = {}, {}, {}


class SpotifyError(Exception):
    pass


def _sp_load():
    if not _sp_tok:
        try:
            with open(SP_TOKEN_FILE) as f:
                _sp_tok.update(json.load(f))
        except (OSError, ValueError):
            pass


def _sp_save():
    os.makedirs(os.path.dirname(SP_TOKEN_FILE), exist_ok=True)
    fd = os.open(SP_TOKEN_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(_sp_tok, f)


def _sp_token_request(data):
    try:
        r = requests.post("https://accounts.spotify.com/api/token", data=data, timeout=8)
    except requests.RequestException:
        raise SpotifyError("Can't reach Spotify")
    if r.status_code != 200:
        if data.get("grant_type") == "refresh_token":  # login revoked/expired
            _sp_tok.clear()
            try:
                os.remove(SP_TOKEN_FILE)
            except OSError:
                pass
            raise SpotifyError(f"Spotify login expired: open http://127.0.0.1:{PORT}/spotify/login on the PC")
        raise SpotifyError(f"Spotify login failed ({r.status_code})")
    j = r.json()
    _sp_tok["access_token"] = j["access_token"]
    _sp_tok["expires_at"] = time.time() + j.get("expires_in", 3600)
    if j.get("refresh_token"):
        _sp_tok["refresh_token"] = j["refresh_token"]
    _sp_save()


def _sp_access():
    if not SPOTIFY_CLIENT_ID:
        raise SpotifyError("Spotify isn't set up: add SPOTIFY_CLIENT_ID in server.py")
    _sp_load()
    if not _sp_tok.get("refresh_token"):
        raise SpotifyError(f"Not logged in: open http://127.0.0.1:{PORT}/spotify/login on the PC")
    if time.time() > _sp_tok.get("expires_at", 0) - 60:
        _sp_token_request({"grant_type": "refresh_token",
                           "refresh_token": _sp_tok["refresh_token"],
                           "client_id": SPOTIFY_CLIENT_ID})
    return _sp_tok["access_token"]


def sp(method, path, params=None, body=None, _retry=True):
    token = _sp_access()
    try:
        r = requests.request(method, SP_API + path, params=params, json=body,
                             headers={"Authorization": f"Bearer {token}"}, timeout=8)
    except requests.RequestException:
        raise SpotifyError("Can't reach Spotify")
    if r.status_code == 401 and _retry:
        _sp_tok["expires_at"] = 0  # force a refresh and try once more
        return sp(method, path, params, body, _retry=False)
    if r.status_code == 429:
        ra = r.headers.get("Retry-After")
        raise SpotifyError("Spotify is rate limiting: wait " + (f"{ra}s" if ra else "a few seconds"))
    if r.status_code == 403:
        raise SpotifyError("Spotify refused (403): app owner needs Premium and your account must be allowed in the app")
    if r.status_code == 404 and path.startswith("/me/player"):
        raise SpotifyError("No active Spotify device: open Spotify on your PC")
    if r.status_code >= 400:
        raise SpotifyError(f"Spotify error {r.status_code}")
    return r


def _fetch_liked(offset, limit):
    j = sp("GET", "/me/tracks", {"limit": limit, "offset": offset}).json()
    tracks = []
    for it in j.get("items", []):
        t = it.get("track") or it.get("item") or {}
        if t.get("uri"):
            tracks.append({"uri": t["uri"], "name": t.get("name", ""),
                           "artist": ", ".join(a.get("name", "") for a in t.get("artists", []))})
    return {"total": j.get("total", 0), "offset": offset, "tracks": tracks}


def liked_page(offset, limit):  # cached briefly so paging back and forth is cheap
    if LIKED_SORT == "artist":
        tracks, msg = get_library()
        if msg:
            raise SpotifyError(msg)
        return {"total": len(tracks), "offset": offset,
                "tracks": [{"uri": t["uri"], "name": t["name"], "artist": t["artist"]}
                           for t in tracks[offset:offset + limit]]}
    key = (offset, limit)
    hit = _liked_cache.get(key)
    if hit and time.time() - hit[0] < 60:
        return hit[1]
    out = _fetch_liked(offset, limit)
    _liked_cache[key] = (time.time(), out)
    return out


# ---- whole-library cache, for sorting Liked Songs by artist ----
# Spotify only returns Liked Songs newest-first, so for artist order we load
# the whole library once (50 songs per request, in the background), sort it
# here, and reuse it. New likes are noticed through the library's song count.
_lib = {"tracks": None, "total": -1, "t": 0, "checked": 0,
        "loading": False, "loaded": 0, "error": None}
_lib_lock = threading.Lock()


def _artist_sort(name):
    n = (name or "").lower().strip()
    return n[4:] if n.startswith("the ") else n


def _load_library():
    try:
        tracks, offset = [], 0
        while True:
            j = sp("GET", "/me/tracks", {"limit": 50, "offset": offset}).json()
            items = j.get("items", [])
            for it in items:
                t = it.get("track") or it.get("item") or {}
                if not t.get("uri"):
                    continue
                names = [a.get("name", "") for a in t.get("artists", [])]
                tracks.append({
                    "uri": t["uri"], "name": t.get("name", ""), "artist": ", ".join(names),
                    "_k": (_artist_sort(names[0] if names else ""),
                           (t.get("album") or {}).get("name", "").lower(),
                           t.get("disc_number") or 1, t.get("track_number") or 0,
                           t.get("name", "").lower())})
            _lib["loaded"] = len(tracks)
            offset += 50
            if not items or offset >= j.get("total", 0):
                break
        tracks.sort(key=lambda x: x["_k"])
        _lib.update(tracks=tracks, total=len(tracks), t=time.time(), checked=time.time())
    except SpotifyError as e:
        _lib["error"] = str(e)
    except Exception as e:
        _lib["error"] = f"Couldn't load your library ({e})"
    finally:
        _lib["loading"] = False


def get_library():
    """(sorted_tracks, None) when ready, else (None, message for the Kindle)."""
    with _lib_lock:
        have = _lib["tracks"] is not None
        if have and not _lib["loading"] and time.time() - _lib["checked"] > 60:
            try:  # cheap check: did the number of liked songs change?
                total = _fetch_liked(0, 1)["total"]
                _lib["checked"] = time.time()
                if total != _lib["total"] or time.time() - _lib["t"] > 6 * 3600:
                    _lib["t"] = 0  # stale: reload below
            except SpotifyError:
                pass  # keep serving what we have
        stale = have and _lib["t"] == 0
        if _lib["error"]:
            err, _lib["error"] = _lib["error"], None  # shown once; next request retries
            if not have:
                return None, err
        if (not have or stale) and not _lib["loading"]:
            _lib.update(loading=True, loaded=0)
            threading.Thread(target=_load_library, daemon=True).start()
        if have:
            return _lib["tracks"], None  # serve the old copy while a reload runs
        return None, (f"Sorting your Liked Songs by artist... {_lib['loaded']} loaded so far. "
                      "Tap Refresh in a few seconds.")


def _liked_slice(start, count):
    """`count` liked songs from position `start` in whichever order is active."""
    if LIKED_SORT == "artist":
        tracks, msg = get_library()
        if msg:
            raise SpotifyError(msg)
        return [t["uri"] for t in tracks[start:start + count]]
    return [t["uri"] for t in _fetch_liked(start, count)["tracks"]]


def pick_device():
    devs = sp("GET", "/me/player/devices").json().get("devices", [])
    if not devs:
        raise SpotifyError("No Spotify device found: open Spotify on your PC")
    if SPOTIFY_DEVICE_NAME:
        for d in devs:
            if SPOTIFY_DEVICE_NAME.lower() in d.get("name", "").lower():
                return d["id"]
    for d in devs:
        if d.get("is_active"):
            return d["id"]
    for d in devs:
        if d.get("type") == "Computer":
            return d["id"]
    return devs[0]["id"]


def play_uris(uris):
    sp("PUT", "/me/player/play", {"device_id": pick_device()}, {"uris": uris[:100]})


# ------------------------------ audio outputs --------------------------------
def _pactl(*args):
    r = subprocess.run(["pactl", *args], capture_output=True, text=True, timeout=4)
    if r.returncode != 0:
        raise RuntimeError(r.stderr.strip() or "pactl failed")
    return r.stdout


def list_sinks():
    """[{'name':..., 'label':...}] for every visible output."""
    sinks = []
    try:
        for d in json.loads(_pactl("-f", "json", "list", "sinks")):
            sinks.append((d["name"], d.get("description") or d["name"]))
    except Exception:  # older pactl: no JSON output
        for line in _pactl("list", "short", "sinks").splitlines():
            cols = line.split("\t")
            if len(cols) > 1:
                sinks.append((cols[1], cols[1]))
    out = []
    for name, desc in sinks:
        if any(h.lower() in name.lower() for h in AUDIO_HIDE):
            continue
        out.append({"name": name, "label": AUDIO_LABELS.get(name, desc)})
    return out


def default_sink():
    return _pactl("get-default-sink").strip()


def set_sink(name):
    _pactl("set-default-sink", name)
    # also move audio that's already playing, so it switches immediately
    try:
        for line in _pactl("list", "short", "sink-inputs").splitlines():
            sid = line.split("\t")[0]
            subprocess.run(["pactl", "move-sink-input", sid, name],
                           capture_output=True, timeout=4)
    except Exception:
        pass


# ------------------------------ now playing ----------------------------------
def track_info():
    fmt = "{{title}}\t{{artist}}\t{{album}}\t{{mpris:length}}\t{{mpris:artUrl}}"
    parts = (pctl("metadata", "--format", fmt).split("\t") + [""] * 5)[:5]
    title, artist, album, length, art = parts
    try:
        length_s = int(length) / 1_000_000
    except ValueError:
        length_s = 0
    key = hashlib.md5(f"{artist}|{title}|{album}".encode()).hexdigest()[:10]
    return {"title": title, "artist": artist, "album": album,
            "length": length_s, "art": art, "key": key}


def now_playing():
    state = pctl("status")
    if state not in ("Playing", "Paused"):
        return {"state": state or "Stopped"}
    t = track_info()
    try:
        pos = float(pctl("position"))
    except ValueError:
        pos = 0.0
    return {"state": state, "title": t["title"], "artist": t["artist"], "album": t["album"],
            "art_id": str(hash(t["art"])) if t["art"] else "", "track_id": t["key"],
            "position": pos, "length": t["length"],
            "shuffle": pctl("shuffle"), "loop": pctl("loop")}  # "" if the player lacks them


# --------------------------------- lyrics ------------------------------------
# Lyrics come from LRCLIB (lrclib.net): free, no API key, community-run.
LRC_HEADERS = {"User-Agent": "kindle-dash (personal project)"}
_lyr_cache = {}


def parse_lrc(s):
    """'[01:23.45] some line' -> [[83.45, 'some line'], ...] sorted by time."""
    out = []
    for line in s.splitlines():
        stamps = re.findall(r"\[(\d+):(\d+(?:\.\d+)?)\]", line)
        if not stamps:
            continue
        txt = re.sub(r"\[\d+:\d+(?:\.\d+)?\]", "", line).strip()
        for m, sec in stamps:
            out.append([round(int(m) * 60 + float(sec), 2), txt])
    out.sort(key=lambda x: x[0])
    return out


def lrclib_lookup(artist, title, album, duration):
    names = [artist]
    first = artist.split(",")[0].strip()
    if first and first != artist:
        names.append(first)
    for name in names:  # exact lookup first
        try:
            r = requests.get("https://lrclib.net/api/get", params={
                "artist_name": name, "track_name": title,
                "album_name": album, "duration": duration},
                headers=LRC_HEADERS, timeout=6)
            if r.status_code == 200:
                return r.json()
        except (requests.RequestException, ValueError):
            pass
    for name in names:  # fallback: search, accept only a close duration match
        try:
            r = requests.get("https://lrclib.net/api/search", params={
                "track_name": title, "artist_name": name},
                headers=LRC_HEADERS, timeout=6)
            res = r.json() if r.status_code == 200 else []
        except (requests.RequestException, ValueError):
            res = []
        good = [c for c in res
                if not duration or abs((c.get("duration") or 0) - duration) <= 5]
        good.sort(key=lambda c: (not c.get("syncedLyrics"),
                                 abs((c.get("duration") or 0) - duration)))
        if good:
            return good[0]
    return None


# -------------------------------- weather ------------------------------------
_wx = {"t": 0, "data": None}
_loc = {"t": 0, "lat": LAT, "lon": LON, "city": ""}


def location():
    """(lat, lon, city). Looked up from the internet address every 6 hours; falls back to LAT/LON."""
    if AUTO_LOCATION and time.time() - _loc["t"] > 6 * 3600:
        _loc["t"] = time.time()  # also stops hammering the lookup if it is down
        try:
            j = requests.get("https://ipwho.is/", timeout=4).json()
            if j.get("success") and j.get("latitude") is not None:
                _loc.update(lat=j["latitude"], lon=j["longitude"], city=j.get("city") or "")
        except Exception:
            pass
    return _loc["lat"], _loc["lon"], _loc["city"]


def weather():
    if time.time() - _wx["t"] < 600 and _wx["data"]:
        return _wx["data"]
    lat, lon, city = location()
    j = requests.get("https://api.open-meteo.com/v1/forecast", params={
        "latitude": lat, "longitude": lon, "timezone": "auto",
        "temperature_unit": UNITS, "wind_speed_unit": WIND_UNIT,
        "current": "temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m",
        "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset",
        "forecast_days": 5}, timeout=6).json()
    c, d = j["current"], j["daily"]
    data = {
        "city": city,
        "temp": round(c["temperature_2m"]), "feels_like": round(c["apparent_temperature"]),
        "humidity": c["relative_humidity_2m"], "wind": round(c["wind_speed_10m"]),
        "wind_unit": WIND_UNIT, "desc": WMO.get(c["weather_code"], "?"),
        "sunrise": d["sunrise"][0][-5:], "sunset": d["sunset"][0][-5:],
        "forecast": [{"day": time.strftime("%a", time.strptime(d["time"][i], "%Y-%m-%d")),
                      "hi": round(d["temperature_2m_max"][i]), "lo": round(d["temperature_2m_min"][i]),
                      "rain": d["precipitation_probability_max"][i],
                      "desc": WMO.get(d["weather_code"][i], "?")} for i in range(5)],
    }
    _wx.update(t=time.time(), data=data)
    return data


# ------------------------------ console (PC status) ---------------------------
_sys_prev = {"t": 0, "cpu": None, "net": None}


def _cpu_percent():
    """CPU use since the previous call, 0-100."""
    try:
        with open("/proc/stat") as f:
            parts = [int(x) for x in f.readline().split()[1:]]
        idle = parts[3] + (parts[4] if len(parts) > 4 else 0)
        total = sum(parts)
        prev = _sys_prev["cpu"]
        _sys_prev["cpu"] = (idle, total)
        if not prev or total == prev[1]:
            return 0
        return round(100 * (1 - (idle - prev[0]) / (total - prev[1])))
    except Exception:
        return 0


def _mem():
    try:
        info = {}
        with open("/proc/meminfo") as f:
            for line in f:
                k, v = line.split(":")
                info[k] = int(v.split()[0]) * 1024
        total = info["MemTotal"]
        used = total - info.get("MemAvailable", info.get("MemFree", 0))
        return {"used": used, "total": total, "pct": round(100 * used / total)}
    except Exception:
        return {"used": 0, "total": 1, "pct": 0}


def _temps():
    """One reading per sensor chip, e.g. {"CPU": 54, "GPU": 47, "SSD": 38}."""
    nice = {"k10temp": "CPU", "coretemp": "CPU", "zenpower": "CPU", "amdgpu": "GPU",
            "nouveau": "GPU", "nvme": "SSD"}
    out = {}
    try:
        for hw in sorted(os.listdir("/sys/class/hwmon")):
            base = f"/sys/class/hwmon/{hw}"
            with open(f"{base}/name") as f:
                name = f.read().strip()
            label = nice.get(name)
            if not label or label in out:
                continue
            for fn in sorted(os.listdir(base)):
                if fn.startswith("temp") and fn.endswith("_input"):
                    with open(f"{base}/{fn}") as f:
                        out[label] = round(int(f.read().strip()) / 1000)
                    break
    except Exception:
        pass
    return out


def _net_rates():
    """(down, up) bytes per second since the previous call, all real interfaces."""
    try:
        rx = tx = 0
        with open("/proc/net/dev") as f:
            for line in list(f)[2:]:
                name, data = line.split(":")
                if name.strip() == "lo" or name.strip().startswith(("veth", "docker", "br-")):
                    continue
                cols = data.split()
                rx += int(cols[0])
                tx += int(cols[8])
        now = time.time()
        prev = _sys_prev["net"]
        _sys_prev["net"] = (now, rx, tx)
        if not prev or now == prev[0]:
            return 0, 0
        dt = now - prev[0]
        return max(0, (rx - prev[1]) / dt), max(0, (tx - prev[2]) / dt)
    except Exception:
        return 0, 0


def _port_open(host, port):
    try:
        with socket.create_connection((host, port), timeout=1.0):
            return True
    except Exception:
        return False


def sys_status():
    disks = []
    for p in DISK_PATHS:
        try:
            u = shutil.disk_usage(p)
            disks.append({"path": p, "used": u.used, "total": u.total,
                          "pct": round(100 * u.used / u.total)})
        except Exception:
            pass
    down, up = _net_rates()
    try:
        with open("/proc/uptime") as f:
            uptime = int(float(f.read().split()[0]))
    except Exception:
        uptime = 0
    try:
        load = round(os.getloadavg()[0], 2)
    except Exception:
        load = 0
    return {
        "cpu": _cpu_percent(), "mem": _mem(), "temps": _temps(), "disks": disks,
        "net": {"down": round(down), "up": round(up)}, "uptime": uptime, "load": load,
        "services": [{"name": n, "ok": _port_open(h, p)} for (n, h, p) in SERVICES],
    }


# ------------------------------ inbox (notifications) -------------------------
_inbox = {"items": [], "seq": 0, "ok": False}
_inbox_lock = threading.Lock()


def inbox_add(app_name, summary, body):
    summary, body = (summary or "").strip(), (body or "").strip()
    if not summary and not body:
        return
    if app_name in INBOX_IGNORE_APPS:
        return
    with _inbox_lock:
        _inbox["seq"] += 1
        _inbox["items"].insert(0, {"id": _inbox["seq"], "app": app_name or "", "summary": summary,
                                   "body": body, "time": time.strftime("%H:%M"), "read": False})
        del _inbox["items"][INBOX_MAX:]


_STR_RE = re.compile(r'string "(.*?)"(?=\n\s*(?:uint32|int32|string|array|\]|\[|dict|boolean|byte|variant|double|int64)|\Z)',
                     re.S)


def _handle_notify_block(block):
    strs = _STR_RE.findall(block)
    if len(strs) >= 4:
        app_name, _icon, summary, body = strs[0], strs[1], strs[2], strs[3]
        inbox_add(app_name, summary, body)


def _inbox_worker():
    """Watch desktop notifications on the session bus (what notify-send, Discord, etc. send)."""
    while True:
        try:
            proc = subprocess.Popen(
                ["dbus-monitor", "--session",
                 "interface='org.freedesktop.Notifications',member='Notify'"],
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
        except FileNotFoundError:
            print("[inbox] dbus-monitor not found - install it (package 'dbus' or 'dbus-tools') to enable the inbox")
            return
        _inbox["ok"] = True
        block, in_notify = [], False
        for line in proc.stdout:
            if line[:1] not in (" ", "\t", "\n"):  # a new message header starts
                if in_notify:
                    _handle_notify_block("".join(block))
                block, in_notify = [], ("member=Notify" in line and line.startswith("method call"))
            elif in_notify:
                block.append(line)
        _inbox["ok"] = False
        time.sleep(5)  # monitor ended; try again


def start_inbox():
    if INBOX_ENABLED:
        threading.Thread(target=_inbox_worker, daemon=True).start()


# -------------------------------- routes -------------------------------------
@app.route("/hello")
def hello():
    """Lets the Kindle recognise this server when it scans the network."""
    host = socket.gethostname()
    return jsonify(app="kindle-dash", id=f"{host}:{PORT}", name=SERVER_NAME or host)


@app.route("/")
def index():
    return "Kindle dash server is running. Try /status or /deck"


@app.route("/status")
def status():
    try:
        w = weather()
    except Exception:
        w = _wx["data"]
    out = {"np": now_playing()}
    if w:  # omit the key when unavailable (JSON null is awkward in Lua)
        out["weather"] = w
    with _inbox_lock:
        out["inbox"] = sum(1 for i in _inbox["items"] if not i["read"])
        out["inbox_seq"] = _inbox["seq"]
    return jsonify(out)


@app.route("/sys")
def sys_route():
    return jsonify(sys_status())


@app.route("/inbox")
def inbox_list():
    with _inbox_lock:
        return jsonify(items=list(_inbox["items"][:30]), total=len(_inbox["items"]),
                       ok=_inbox["ok"], enabled=INBOX_ENABLED)


@app.route("/inbox/read", methods=["POST"])
def inbox_read():
    with _inbox_lock:
        for i in _inbox["items"]:
            i["read"] = True
    return jsonify(ok=True)


@app.route("/inbox/dismiss/<int:nid>", methods=["POST"])
def inbox_dismiss(nid):
    with _inbox_lock:
        _inbox["items"] = [i for i in _inbox["items"] if i["id"] != nid]
    return jsonify(ok=True)


@app.route("/inbox/clear", methods=["POST"])
def inbox_clear():
    with _inbox_lock:
        _inbox["items"] = []
    return jsonify(ok=True)


@app.route("/notify", methods=["POST", "GET"])
def notify_route():
    """Lets scripts drop a message into the Kindle's inbox."""
    inbox_add(request.args.get("app", "Script"), request.args.get("title", ""), request.args.get("body", ""))
    return jsonify(ok=True)


@app.route("/ctl/<cmd>", methods=["POST"])
def ctl(cmd):
    if cmd not in BUILTIN:
        abort(400)
    try:
        run_detached(BUILTIN[cmd]())
    except Exception as e:
        print(f"[ctl] {cmd} failed: {e}")
        return jsonify(ok=False), 500
    return jsonify(ok=True)


@app.route("/lyrics")
def lyrics():
    if pctl("status") not in ("Playing", "Paused"):
        return jsonify(key="", found=False)
    t = track_info()
    key = t["key"]
    if key in _lyr_cache:
        return jsonify(_lyr_cache[key])
    try:
        rec = lrclib_lookup(t["artist"], t["title"], t["album"], int(t["length"]))
    except Exception as e:
        print(f"[lyrics] {e}")
        return jsonify(key=key, found=False)  # transient: don't cache
    out = {"key": key, "found": False, "instrumental": False, "synced": [], "plain": ""}
    if rec:
        synced = parse_lrc(rec.get("syncedLyrics") or "")
        plain = rec.get("plainLyrics") or "\n".join(l[1] for l in synced)
        out.update(found=bool(synced or plain.strip()),
                   instrumental=bool(rec.get("instrumental")),
                   synced=synced, plain=plain)
    if len(_lyr_cache) > 300:
        _lyr_cache.clear()
    _lyr_cache[key] = out
    return jsonify(out)


def _local_only():
    if request.remote_addr not in ("127.0.0.1", "::1"):
        abort(403)


@app.route("/spotify/login")
def spotify_login():
    _local_only()
    if not SPOTIFY_CLIENT_ID:
        return "Set SPOTIFY_CLIENT_ID in server.py first, then restart.", 400
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    state = secrets.token_urlsafe(16)
    _sp_auth.update(state=state, verifier=verifier)
    return redirect("https://accounts.spotify.com/authorize?" + urllib.parse.urlencode({
        "client_id": SPOTIFY_CLIENT_ID, "response_type": "code",
        "redirect_uri": SP_REDIRECT, "scope": SP_SCOPES, "state": state,
        "code_challenge_method": "S256", "code_challenge": challenge}))


@app.route("/spotify/callback")
def spotify_callback():
    _local_only()
    if request.args.get("error"):
        return f"Spotify said: {escape(request.args['error'])}", 400
    if not _sp_auth or request.args.get("state") != _sp_auth.get("state"):
        return "State mismatch: start again at /spotify/login", 400
    try:
        _sp_token_request({
            "grant_type": "authorization_code", "code": request.args.get("code", ""),
            "redirect_uri": SP_REDIRECT, "client_id": SPOTIFY_CLIENT_ID,
            "code_verifier": _sp_auth["verifier"]})
    except SpotifyError as e:
        return f"Login failed: {escape(str(e))}", 400
    _sp_auth.clear()
    return "Spotify connected. You can close this tab."


@app.route("/liked")
def liked():
    try:
        offset = max(0, int(request.args.get("offset", 0)))
        limit = min(50, max(1, int(request.args.get("limit", 8))))
        return jsonify(liked_page(offset, limit))
    except ValueError:
        return jsonify(error="bad request")
    except SpotifyError as e:
        return jsonify(error=str(e))


@app.route("/liked/play/<int:offset>/<int:i>", methods=["POST"])
def liked_play(offset, i):
    """Play the tapped track and the 49 liked songs after it."""
    try:
        uris = _liked_slice(offset + i, 50)
        if not uris:
            raise SpotifyError("That track is no longer in your Liked Songs")
        play_uris(uris)
        return jsonify(ok=True)
    except SpotifyError as e:
        return jsonify(error=str(e))


@app.route("/liked/shuffle", methods=["POST"])
def liked_shuffle():
    """Shuffle a random 50-song window of your Liked Songs (not your whole library)."""
    try:
        total = _fetch_liked(0, 1)["total"]
        if not total:
            raise SpotifyError("No Liked Songs found")
        tracks = _fetch_liked(random.randint(0, max(0, total - 50)), 50)["tracks"]
        random.shuffle(tracks)
        play_uris([t["uri"] for t in tracks])
        return jsonify(ok=True)
    except SpotifyError as e:
        return jsonify(error=str(e))


def _queue_item(t):
    if not t:
        return None
    artist = ", ".join(a.get("name", "") for a in t.get("artists", []))
    if not artist:  # podcast episode
        artist = (t.get("show") or {}).get("name", "")
    return {"name": t.get("name", ""), "artist": artist}


@app.route("/queue")
def queue():
    """What Spotify will play next (up to ~20 songs, as Spotify reports them)."""
    try:
        r = sp("GET", "/me/player/queue")
        j = r.json() if (r.status_code == 200 and r.content) else {}
    except SpotifyError as e:
        msg = str(e)
        if "403" in msg:
            msg += f". If you logged in before this update, log in again: http://127.0.0.1:{PORT}/spotify/login"
        return jsonify(error=msg)
    except ValueError:
        j = {}
    out = {"queue": [i for i in (_queue_item(t) for t in j.get("queue", [])) if i]}
    now = _queue_item(j.get("currently_playing"))
    if now:  # omit the key rather than send null (awkward in Lua)
        out["now"] = now
    return jsonify(out)


@app.route("/audio")
def audio():
    try:
        sinks, cur = list_sinks(), default_sink()
    except Exception as e:
        print(f"[audio] {e}")
        return jsonify(cols=AUDIO_COLS, current="", sinks=[])
    return jsonify(cols=AUDIO_COLS, current=cur, sinks=sinks)


@app.route("/audio/<int:i>", methods=["POST"])
def audio_set(i):
    try:
        sink = list_sinks()[i]
        set_sink(sink["name"])
    except IndexError:
        abort(404)
    except Exception as e:
        print(f"[audio] switch failed: {e}")
        return jsonify(ok=False), 500
    return jsonify(ok=True)


@app.route("/deck")
def deck():
    return jsonify(cols=DECK_COLS, pages=[
        {"name": p["name"], "buttons": [{"label": b["label"]} for b in p["buttons"]]}
        for p in DECK_PAGES])


@app.route("/deck/<int:p>/<int:i>", methods=["POST"])
def deck_press(p, i):
    try:
        b = DECK_PAGES[p]["buttons"][i]
    except IndexError:
        abort(404)
    try:
        argv, shell = resolve(b)
        run_detached(argv, shell)
    except Exception as e:
        print(f"[deck] '{b.get('label')}' failed: {e}")
        return jsonify(ok=False), 500
    return jsonify(ok=True)


_art_cache = {"url": None, "img": None}


@app.route("/art.png")
def art():
    url = pctl("metadata", "mpris:artUrl")
    if not url:
        abort(404)
    size = min(1000, max(100, request.args.get("size", 600, type=int)))
    try:
        if _art_cache["url"] != url:
            if url.startswith("file://"):
                img = Image.open(url[7:])
            else:
                img = Image.open(io.BytesIO(requests.get(url, timeout=6).content))
            _art_cache.update(url=url, img=ImageOps.autocontrast(img.convert("L")))
        img = _art_cache["img"]
        scale = size / max(img.size)
        if scale != 1:  # resize to what the Kindle asked for (poster mode wants it big)
            lanczos = getattr(Image, "Resampling", Image).LANCZOS
            img = img.resize((max(1, round(img.width * scale)),
                              max(1, round(img.height * scale))), lanczos)
        buf = io.BytesIO()
        img.save(buf, "PNG")
        buf.seek(0)
        return send_file(buf, mimetype="image/png")
    except Exception:
        abort(404)


if __name__ == "__main__":
    print("volume backend:", volume_backend() or "NONE FOUND")
    start_inbox()
    app.run(host=HOST, port=PORT)
