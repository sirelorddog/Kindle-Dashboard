#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
pgrep -f "$DIR/server.py" >/dev/null && exit 0   # already running
exec "$DIR/venv/bin/python" "$DIR/server.py" >>/tmp/dash.log 2>&1
